package mrcof.code.senior_tech_support_app;

public class UserHelperClass {
    private String username;

    public UserHelperClass() {
    }

    public UserHelperClass(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
