package mrcof.code.senior_tech_support_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import com.google.android.material.textfield.TextInputLayout;

public class Dashboard extends AppCompatActivity {

    //Variables
    Button regTVBtn, regPhoneBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_dashboard);

        //Hooks
        regTVBtn = (Button) findViewById(R.id.SelectedTV);
        regPhoneBtn = (Button) findViewById(R.id.SelectedPhone);

        regTVBtn.setOnClickListener(v -> {
            Intent intent = new Intent(Dashboard.this, TV.class); // From here to there

            // After saving user name go to next activity
            startActivity(intent);
            finish();
        });

        regPhoneBtn.setOnClickListener(v -> {
            Intent intent = new Intent(Dashboard.this, Phone.class); // From here to there

            // After saving user name go to next activity
            startActivity(intent);
            finish();
        });

    }
}